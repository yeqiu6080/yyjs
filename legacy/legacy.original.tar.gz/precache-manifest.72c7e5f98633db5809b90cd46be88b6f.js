self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "5c231316b11f857b6b24",
    "url": "css/app.30b45c25.css"
  },
  {
    "revision": "bf896ab39835a4e161a4",
    "url": "css/chunk-vendors.094863c6.css"
  },
  {
    "revision": "535877f50039c0cb49a6196a5b7517cd",
    "url": "fonts/element-icons.535877f5.woff"
  },
  {
    "revision": "732389ded34cb9c52dd88271f1345af9",
    "url": "fonts/element-icons.732389de.ttf"
  },
  {
    "revision": "f6d0c0e63fdb65026fbd72f75d3ba390",
    "url": "index.html"
  },
  {
    "revision": "2d12777f2703612307ff4a12f1b21899",
    "url": "ixarea-stats.js"
  },
  {
    "revision": "dd306d42042383c7509ba12954fb9559",
    "url": "js/0.6dd6b2eb.worker.js"
  },
  {
    "revision": "5c231316b11f857b6b24",
    "url": "js/app.542726a4.js"
  },
  {
    "revision": "bf896ab39835a4e161a4",
    "url": "js/chunk-vendors.f9009ace.js"
  },
  {
    "revision": "02995355b96ddf2519cd49f8aa73bb46",
    "url": "loader.js"
  },
  {
    "revision": "523b1a2eae8cb533fa6bd73831308f09",
    "url": "static/kgm.mask"
  },
  {
    "revision": "cd1d395410107c66b4534ec93f0073d3",
    "url": "web-manifest.json"
  }
]);